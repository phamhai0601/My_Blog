<?php
	include 'function.php';
	include 'db.php';
	$db = new Database();
?>