<?php



/*function html_form($title='',$html='',$id=''){

	echo '

	<pre><form method="post" id="form">

	<input value="'.$id.'" name="id" type="hidden">

	TITLE : <input value="'.$title.'" name="title" type="text">

	HTML : <textarea style="width:350px;" name="html" placeholder="Put your html here..">'.$html.'

	</textarea>

	<input value="submit" type="submit">

	</form></pre>

	';

}*/

















?>