<a href="add_blog.php">add blog</a><br>

<a href="edit_blog.php">edit blog</a><br>

<a href="delete_blog.php">delete blog</a>